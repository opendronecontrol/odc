
Open Drone Control

MaxMSP project template

For use with ARDrone 2.0 you will need to download xuggle-xuggler-5.4.jar for the video decoding from:
  http://xuggle.googlecode.com/svn/trunk/repo/share/java/xuggle/xuggle-xuggler/5.4/xuggle-xuggler-5.4.jar

Max refuses to load the native libraries from within the packaged jar so for now you also have to extract them manually:
Jar files are basically zip file filled with compiled java classes and other goodies.

  1. open xuggle-xuggler-5.4.jar with unarchive program of choice (may be easier if you rename xuggle-xuggler-5.4.jar to .zip)
  2. find the appropriate native library for your system inside:
      (i.e osx -> /com/xuggle/ferry/x86_64-xuggle-darwin11/libxuggle.dylib)

  3. Place the native library and the original jar file in the template project lib directory

Have fun!

